/** Automatically generated file. DO NOT MODIFY */
package com.diplomadourp.ejemplolbs;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}