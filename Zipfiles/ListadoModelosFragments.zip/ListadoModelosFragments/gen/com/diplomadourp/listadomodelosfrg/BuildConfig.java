/** Automatically generated file. DO NOT MODIFY */
package com.diplomadourp.listadomodelosfrg;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}