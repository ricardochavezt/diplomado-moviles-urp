package com.android_urp.ejemplointentsforresult;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

	Button btnAcntivityResultado;
	TextView tviMensaje;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        tviMensaje = (TextView) findViewById(R.id.txtResultado);
        btnAcntivityResultado = (Button) findViewById(R.id.btnActivityResultado);
        btnAcntivityResultado.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MainActivity.this,
						ResultActivity.class);
				startActivityForResult(intent, 100);
			}
		});
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
    		Intent data) {
    	// TODO Auto-generated method stub
    	super.onActivityResult(requestCode, resultCode, data);
    	Log.i("ActivityResult", "Request code: " + requestCode);
    	
    	if (resultCode == RESULT_OK) {
			String mensaje = data.getExtras().getString("mensaje");
			tviMensaje.setText(mensaje);
		}
    }
}
