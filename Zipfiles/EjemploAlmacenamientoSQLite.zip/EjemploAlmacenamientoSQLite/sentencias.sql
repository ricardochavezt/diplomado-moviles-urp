CREATE TABLE IF NOT EXISTS T_MODELO 
(id integer primary key AUTOINCREMENT, 
nombre TEXT, profesion TEXT, ciudad TEXT, 
fechanacimiento TEXT, foto TEXT)