/** Automatically generated file. DO NOT MODIFY */
package com.diplomadourp.listadomodelos;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}